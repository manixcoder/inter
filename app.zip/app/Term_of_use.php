<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Term_of_use extends Model
{
    protected $table = 'term_of_use';
    public $timestamps = true;    
}
