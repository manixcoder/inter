<?php

namespace App;
use Illuminate\Database\Eloquent\Model;

class Aboutus extends Model{
    protected $table = 'about_us';
    public $timestamps = true;    
}
