<div class="lgcontainer">
        <ul class="footer_menu col_grid7 text-left">
        <li><a href="{{ URL::to('aboutus')}}">About Us</a></li>
          <li><a href="{{ URL::to('contactus')}}">Contact Us</a></li>
          <li><a href="{{ URL::to('termsofuse')}}">Terms of Use</a></li>
          <li><a href="{{ URL::to('privacypolicy')}}">Privacy Policy</a></li>
        </ul>
        <ul class="social_icon col_grid5 text-right">
          <li>
            <a href="https://open.spotify.com/user/64p2h14btruk2aydbijnajk9o"><i class="fa fa-spotify" aria-hidden="true"></i></a>
          </li>
          <li>
            <a href="https://www.facebook.com/Theinternify"><i class="fa fa-facebook" aria-hidden="true"></i></a>
          </li>
          <li>
            <a href="https://twitter.com/TInternify "><i class="fa fa-twitter" aria-hidden="true"></i></a>
          </li>
          <li>
            <a href="https://www.instagram.com/theinternify/"><i class="fa fa-instagram" aria-hidden="true"></i></a>
          </li>
          <li>
            <a href="https://www.linkedin.com/company/the-internify/ "><i class="fa fa-linkedin" aria-hidden="true"></i></a>
          </li>
        </ul>
      </div>