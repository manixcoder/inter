<section class="home" id="home">
  <div class="container">
    <div class="row">
      <div class="col-sm-12 text-center">
        <div class="home-wrapper">
          <h1 class="home-text"><span class="rotate">Comming Soon</span></h1>
         <!--  <p class="m-t-30">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed feugiat arcu ut orci porta, eget porttitor felis suscipit.<br> Sed a nisl ullamcorper, tempus augue at, rutrum lacus. Duis et turpis eros.</p> -->

          <!-- COUNTDOWN -->
          <div class="row m-t-40">
            <div class="col-sm-12">
              <div class="lj-countdown">
              <!--   <div class="">
                  <div>
                    <div>
                      <span>0</span><span>days</span></div><div><span>0</span><span>hours</span></div></div><div class="lj-countdown-ms"><div><span>0</span><span>minutes</span></div><div><span>0</span><span>seconds</span>
                      </div>
                    </div>
                  </div> -->
                </div>
              </div>
            </div>
            <!-- /COUNTDOWN -->

          </div>
        </div>
      </div>
    </div>
  </section>