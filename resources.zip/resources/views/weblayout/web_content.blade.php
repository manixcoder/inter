@include('weblayout.web_header')
@include($data['web_content'])
@include('weblayout.web_footer')