@include('layouts.header')
@include('layouts.menubar')

@include($data['content'])

@include('layouts.footer')